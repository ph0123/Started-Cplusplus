// 02_07 Lambdas
#include <iostream>

using namespace std;

int main() {

//  auto myInc = incrementer();
//  cout << "myInc = " << myInc() << endl;
//  cout << "myInc = " << myInc() << endl;
//  cout << "myInc = " << myInc() << endl;
//  cout << "myInc = " << myInc() << endl;

  return 0;
}