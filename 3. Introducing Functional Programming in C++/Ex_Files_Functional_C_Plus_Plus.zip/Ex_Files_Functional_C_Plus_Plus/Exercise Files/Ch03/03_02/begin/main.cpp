#include <iostream>
#include <vector>
using namespace std;


int main() {
//  cout << "5! = " << factorial(5) << endl;
//  cout << "Factorial<4> " << Factorial<4>::value << endl;
//  cout << "Factorial<5> " << Factorial<5>::value << endl;
  return 0;
}
