#include <iostream>
#include <vector>
using namespace std;

int main() {
  // cout << "8 cubed = " << cube(8) << endl;
  // cout << "5 cubed = " << Cube<5>::value << endl;
  return 0;
}
