// Learning C++ 
// Exercise 01_03
// Hello World, by Eduardo Corpeño 

#include <iostream>

using namespace std;

int main(){
	cout << "Hi There!" << endl;
	return(0);
}
