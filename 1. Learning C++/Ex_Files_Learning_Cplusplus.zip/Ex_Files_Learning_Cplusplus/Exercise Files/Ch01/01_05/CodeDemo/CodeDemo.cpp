// Learning C++ 
// Challenge Solution 01_05
// Console Interaction, by Eduardo Corpeño 

#include <iostream>
#include <string>

using namespace std;

int main(){
	string str;
	cout << "Enter your name: ";
	cin >> str;
	cout << "Nice to meet you, " << str << "!" << endl;
	return (0);
}
