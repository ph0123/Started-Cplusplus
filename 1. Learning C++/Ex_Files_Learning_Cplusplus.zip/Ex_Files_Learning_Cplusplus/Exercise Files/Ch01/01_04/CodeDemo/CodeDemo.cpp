// Learning C++ 
// Challenge 01_04
// Console Interaction, by Eduardo Corpeño 

#include <iostream>
#include <string>

using namespace std;

int main(){
	string str;
	cin >> str;
	cout << str;
	return(0);
}
