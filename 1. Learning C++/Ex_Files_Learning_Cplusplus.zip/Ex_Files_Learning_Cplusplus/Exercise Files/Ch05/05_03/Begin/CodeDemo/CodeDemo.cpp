// Learning C++ 
// Exercise 05_03
// Function Parameters, by Eduardo Corpeño 

#include <iostream>

using namespace std;

int main(){
    int a = 9, b;

    cout << "a = " << a << ", b = " << b << endl;
    // swap
    cout << "a = " << a << ", b = " << b << endl;
    // swap
    cout << "a = " << a << ", b = " << b << endl;
    return (0);
}
