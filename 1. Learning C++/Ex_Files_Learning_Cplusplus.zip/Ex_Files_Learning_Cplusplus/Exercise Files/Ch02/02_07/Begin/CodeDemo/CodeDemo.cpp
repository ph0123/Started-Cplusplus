// Learning C++ 
// Exercise 02_07
// Arrays, by Eduardo Corpeño 

#include <iostream>

using namespace std;

int main(){
    return (0);
}
