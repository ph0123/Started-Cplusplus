// Learning C++ 
// Exercise 02_04
// Type inference with auto, by Eduardo Corpeño 

#include <iostream>
#include <typeinfo>

using namespace std;

int main(){
    return (0);
}
