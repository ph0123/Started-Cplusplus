// Learning C++ 
// Exercise 02_05
// Preprocessor directives, by Eduardo Corpeño 

#include <iostream>

using namespace std;

int main(){
    return (0);
}
