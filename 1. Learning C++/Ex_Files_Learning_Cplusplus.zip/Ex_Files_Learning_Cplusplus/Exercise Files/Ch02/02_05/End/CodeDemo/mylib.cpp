#include "mylib.hpp"

void myfunc(){
    cout<<"hey!!!"<<endl;
}