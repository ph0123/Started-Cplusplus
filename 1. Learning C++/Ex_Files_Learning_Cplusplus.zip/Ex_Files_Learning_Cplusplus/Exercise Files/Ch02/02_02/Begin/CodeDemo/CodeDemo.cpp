// Learning C++ 
// Exercise 02_02
// Variables, by Eduardo Corpeño 

#include <iostream>

using namespace std;

int main(){
    cout << "Hi There!" << endl;
    return (0);
}
