// Learning C++ 
// Exercise 03_05
// Vectors, by Eduardo Corpeño 

#include <iostream>
#include <string>
#include "cow.h"

using namespace std;

int main(){
    return (0);
}
